﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string greeting1 = "Hello World!";
            string greeting2 = "Hello Boy!";
            int number = 1;
            Console.WriteLine($"Learning C#, we put {greeting1} and {greeting2}");
            Console.WriteLine("Variables yada yada {0}", number);

        }
    }
}
