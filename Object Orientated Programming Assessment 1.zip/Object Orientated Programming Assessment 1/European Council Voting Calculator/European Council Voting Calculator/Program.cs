﻿using System;

namespace European_Council_Voting_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            //Arrays for countries and populations
            string[] countries = new string[] {"Austria", "Belgium","Bulgaria","Croatia","Cyprus","Czech Republic","Denmark","Estonia","Finland","France","Germany","Greece","Hungary","Ireland","Italy","Latvia","Lithuania","Luxembourg","Malta","Netherlands","Poland","Portugal","Romania","Slovakia","Slovenia","Spain","Sweden"};
            string[] countryPopulations = new string[] {"1.98", "2.56", "1.56", "0.91", "0.20", "2.35", "1.30", "0.30", "1.23", "14.98", "18.54", "2.40", "2.18", "1.10","13.65","0.43","0.62","0.14","0.11","3.89","8.49","2.30","4.34","1.22","0.47","10.49","2.29"};

            //declaring variables
            int iterationValue = 0;
            float countriesAgreed = 0;
            float populationPercentage = 0;
            //while value is less than the number of countries loop
            while(iterationValue < 27)
            {
                Console.WriteLine("\n{0}\nYes, No or Abstain: ", countries[iterationValue]);
                //taking user input on whether the country is agreeing, disagreeing or abstaining
                string userInput = Console.ReadLine();
                //changing the input to all lowercase
                userInput = userInput.ToLower();
                if(userInput == "yes")
                {
                    //changing population value from string to float
                    float tempPopulation = float.Parse(countryPopulations[iterationValue]);
                    //increasing the population count by the population increase
                    populationPercentage += tempPopulation;
                    //increasing the country count by one
                    countriesAgreed += 1;
                }
                //increasing loop variable by one
                iterationValue += 1;
            }
            //turning countriesAgreed into a percentage
            countriesAgreed = (countriesAgreed/27) * 100;
            //if population is greater than the amount needed for approval
            if(populationPercentage > 65)
            {
                //if country agreed is greater than the amount needed for approval
                if(countriesAgreed > 55)
                {
                    Console.WriteLine("\nFinal Result has been Approved.\n{0}% of the Population Agreed.\n{1}% of Countries Agreed.",populationPercentage,countriesAgreed);
                }
                //if country agreed is less than the amount needed for approval
                if (countriesAgreed <= 55)
                {
                    Console.WriteLine("\nFinal Result has not been Approved.\n{0}% of the Population Agreed.\n{1}% of Countries Agreed.", populationPercentage, countriesAgreed);
                }
            }
            //if population is less than or equal the amount needed for approval
            if (populationPercentage <= 65)
            {
                Console.WriteLine("\nFinal Result has not been Approved.\n{0}% of the Population Agreed.\n{1}% of Countries Agreed.", populationPercentage, countriesAgreed);
            }
        }
    }
}
