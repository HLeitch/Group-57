﻿using System;

namespace test
{
    public abstract class Vars
    {
        //Arrays for countries and populations
        public static string[] countries = new string[] { "Austria", "Belgium", "Bulgaria", "Croatia", "Cyprus", "Czech Republic", "Denmark", "Estonia", "Finland", "France", "Germany", "Greece", "Hungary", "Ireland", "Italy", "Latvia", "Lithuania", "Luxembourg", "Malta", "Netherlands", "Poland", "Portugal", "Romania", "Slovakia", "Slovenia", "Spain", "Sweden" };
        public static string[] countryPopulations = new string[] { "1.98", "2.56", "1.56", "0.91", "0.20", "2.35", "1.30", "0.30", "1.23", "14.98", "18.54", "2.40", "2.18", "1.10", "13.65", "0.43", "0.62", "0.14", "0.11", "3.89", "8.49", "2.30", "4.34", "1.22", "0.47", "10.49", "2.29" };

        //declaring variables
        public static int iterationValue = 0;
        public static float countriesAgreed = 0;
        public static float populationPercentage = 0;
    }

    public class Inputs
    {
        private static void Main()
        {
            
            //while value is less than the number of countries loop
            while (Vars.iterationValue < 27)
            {
                Console.WriteLine("\n{0}\nYes, No or Abstain: ", Vars.countries[Vars.iterationValue]);
                //taking user input on whether the country is agreeing, disagreeing or abstaining
                string userInput = Console.ReadLine();
                //changing the input to all lowercase
                userInput = userInput.ToLower();
                if (userInput == "yes")
                {
                    //changing population value from string to float
                    float tempPopulation = float.Parse(Vars.countryPopulations[Vars.iterationValue]);
                    //increasing the population count by the population increase
                    Vars.populationPercentage += tempPopulation;
                    //rounds the population to a 2d.p. percentage, rounds towards the nearest whole no.
                    Math.Round(Vars.populationPercentage, 2, MidpointRounding.AwayFromZero);
                    //if the population exceeds 100, population equals 100
                    if(Vars.populationPercentage > 100)
                    {
                        Vars.populationPercentage = 100;
                    }
                    //increasing the country count by one
                    Vars.countriesAgreed += 1;
                }
                //increasing loop variable by one
                Vars.iterationValue += 1;
            }
            //turning countriesAgreed into a percentage
            Vars.countriesAgreed = (Vars.countriesAgreed / 27) * 100;
            ExecuteFunction.Execute();
        }
    }
    public class ExecuteFunction
    {
        public static void Execute()
        {
           
            //if population is greater than the amount needed for approval
            if (Vars.populationPercentage > 65)
            {
                //if country agreed is greater than the amount needed for approval
                if (Vars.countriesAgreed > 55)
                {
                    Console.WriteLine("\nFinal Result has been Approved.\n{0}% of the Population Agreed.\n{1}% of Countries Agreed.", Vars.populationPercentage, Vars.countriesAgreed);
                }
                //if country agreed is less than the amount needed for approval
                if (Vars.countriesAgreed <= 55)
                {
                    Console.WriteLine("\nFinal Result has not been Approved.\n{0}% of the Population Agreed.\n{1}% of Countries Agreed.", Vars.populationPercentage, Vars.countriesAgreed);
                }
            }
            //if population is less than or equal the amount needed for approval
            if (Vars.populationPercentage <= 65)
            {
                Console.WriteLine("\nFinal Result has not been Approved.\n{0}% of the Population Agreed.\n{1}% of Countries Agreed.", Vars.populationPercentage, Vars.countriesAgreed);
            }
        }
    }
}